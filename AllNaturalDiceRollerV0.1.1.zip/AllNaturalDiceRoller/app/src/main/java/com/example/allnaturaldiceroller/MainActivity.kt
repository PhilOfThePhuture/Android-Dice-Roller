package com.example.allnaturaldiceroller

import android.media.MediaPlayer
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    var d4Dice = 0
    var d6Dice = 0
    var d8Dice = 0
    var d10Dice = 0
    var d12Dice = 0
    var d20Dice = 0
    var d100Dice = 0
    var bonus1 = 0
    var bonus2 = 0
    var bonus3 = 0
    var myRolls: ArrayList<String>? = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
    }

    fun onClick(view: View)
    {
        // Keeps the data for number of dice rolled and what each dice rolled
        var rollString = ""
        var diceCalculation = 0
        var d4Value = 0
        var d6Value = 0
        var d8Value = 0
        var d10Value = 0
        var d12Value = 0
        var d20Value = 0
        var d100Value = 0
        var rollsListView = findViewById<ListView>(R.id.RollsListView)
        var rollTextView = findViewById<TextView>(R.id.textViewRoll)

        // Handles creating variables for the number of dice of each type
        countDice()

        // The following "if" statements go through each type of dice and roll all of each of them
        var x = 1
        if (d4Dice > 0)
        {
            // Rolls the dice
            d4Value = Random.nextInt(1, 5)
            // Adds value rolled to total roll amount
            diceCalculation += d4Value
            // Starts this set of dice and adds the first number rolled
            rollString += "$d4Dice" + "d4($d4Value"
            if (d4Dice > 1)
            {
                while (x < d4Dice)
                {
                    //does similar to above but for all remaining dice
                    d4Value = Random.nextInt(1, 5)
                    diceCalculation += d4Value
                    rollString += ", $d4Value"
                    x++
                }
                x = 1
            }
            // Adds the ending bracket to the string depending on if there are any other
            // types of dice being used
            rollString += if (d6Dice == 0 && d8Dice == 0 && d10Dice == 0 && d12Dice == 0 &&
                d20Dice == 0 && d100Dice == 0 && bonus1 == 0 && bonus2 == 0 && bonus3 == 0) {
                ")"
            } else
                ") + "

        }
        if (d6Dice > 0)
        {
            // Rolls the dice
            d6Value = Random.nextInt(1, 7)
            // Adds value rolled to total roll amount
            diceCalculation += d6Value
            // Starts this set of dice and adds the first number rolled
            rollString += "$d6Dice" + "d6($d6Value"
            if (d6Dice > 1)
            {
                while (x < d6Dice)
                {
                    //does similar to above but for all remaining dice
                    d6Value = Random.nextInt(1, 7)
                    diceCalculation += d6Value
                    rollString += ", $d6Value"
                    x++
                }
                x = 1
            }
            // Adds the ending bracket to the string depending on if there are any other
            // types of dice being used
            rollString += if (d8Dice == 0 && d10Dice == 0 && d12Dice == 0 && d20Dice == 0 &&
                d100Dice == 0 && bonus1 == 0 && bonus2 == 0 && bonus3 == 0) {
                ")"
            } else
                ") + "
        }
        if (d8Dice > 0)
        {
            // Rolls the dice
            d8Value = Random.nextInt(1, 9)
            // Adds value rolled to total roll amount
            diceCalculation += d8Value
            // Starts this set of dice and adds the first number rolled
            rollString += "$d8Dice" + "d8($d8Value"
            if (d8Dice > 1)
            {
                while (x < d8Dice)
                {
                    //does similar to above but for all remaining dice
                    d8Value = Random.nextInt(1, 9)
                    diceCalculation += d8Value
                    rollString += ", $d8Value"
                    x++
                }
            }
            // Adds the ending bracket to the string depending on if there are any other
            // types of dice being used
            rollString += if (d10Dice == 0 && d12Dice == 0 && d20Dice == 0 && d100Dice == 0 &&
                bonus1 == 0 && bonus2 == 0 && bonus3 == 0) {
                ")"
            } else
                ") + "
        }
        if (d10Dice > 0)
        {
            // Rolls the dice
            d10Value = Random.nextInt(1, 11)
            // Adds value rolled to total roll amount
            diceCalculation += d10Value
            // Starts this set of dice and adds the first number rolled
            rollString += "$d10Dice" + "d10($d10Value"
            if (d10Dice > 1)
            {
                while (x < d10Dice)
                {
                    //does similar to above but for all remaining dice
                    d10Value = Random.nextInt(1, 11)
                    diceCalculation += d10Value
                    rollString += ", $d10Value"
                    x++
                }
            }
            // Adds the ending bracket to the string depending on if there are any other
            // types of dice being used
            rollString += if (d12Dice == 0 && d20Dice == 0 && d100Dice == 0 && bonus1 == 0 &&
                bonus2 == 0 && bonus3 == 0) {
                ")"
            } else
                ") + "
        }
        if (d12Dice > 0)
        {
            // Rolls the dice
            d12Value = Random.nextInt(1, 13)
            // Adds value rolled to total roll amount
            diceCalculation += d12Value
            // Starts this set of dice and adds the first number rolled
            rollString += "$d12Dice" + "d12($d12Value"
            if (d12Dice > 1)
            {
                while (x < d12Dice)
                {
                    //does similar to above but for all remaining dice
                    d12Value = Random.nextInt(1, 13)
                    diceCalculation += d12Value
                    rollString += ", $d12Value"
                    x++
                }
            }
            // Adds the ending bracket to the string depending on if there are any other
            // types of dice being used
            rollString += if (d20Dice == 0 && d100Dice == 0 && bonus1 == 0 && bonus2 == 0 &&
                bonus3 == 0) {
                ")"
            } else
                ") + "
        }
        if (d20Dice > 0)
        {
            // Rolls the dice
            d20Value = Random.nextInt(1, 21)
            // Adds value rolled to total roll amount
            diceCalculation += d20Value
            // Starts this set of dice and adds the first number rolled
            rollString += "$d20Dice" + "d20($d20Value"
            if (d20Dice > 1)
            {
                while (x < d20Dice)
                {
                    //does similar to above but for all remaining dice
                    d20Value = Random.nextInt(1, 21)
                    diceCalculation += d20Value
                    rollString += ", $d20Value"
                    x++
                }
            }
            // Adds the ending bracket to the string depending on if there are any other
            // types of dice being used
            rollString += if (d100Dice == 0 && bonus1 == 0 && bonus2 == 0 && bonus3 == 0) {
                ")"
            } else
                ") + "
        }
        if (d100Dice > 0)
        {
            // Rolls the dice
            d100Value = Random.nextInt(1, 101)
            // Adds value rolled to total roll amount
            diceCalculation += d100Value
            // Starts this set of dice and adds the first number rolled
            rollString += "$d100Dice" + "d100($d100Value"
            if (d100Dice > 1)
            {
                while (x < d100Dice)
                {
                    //does similar to above but for all remaining dice
                    d100Value = Random.nextInt(1, 101)
                    diceCalculation += d100Value
                    rollString += ", $d100Value"
                    x++
                }
            }
            // Adds the ending bracket to the string depending on if there are any other
            // types of dice being used
            rollString += if (bonus1 == 0 && bonus2 == 0 && bonus3 == 0) {
                ")"
            } else
                ") + "
        }
        // Accounts for each combination of empty bonuses then adds the ones that aren't empty
        // to the string
        rollString += if (bonus1 != 0 && bonus2 == 0 && bonus3 == 0) {
            "$bonus1"
        } else if (bonus1 == 0 && bonus2 != 0 && bonus3 == 0) {
            "$bonus2"
        } else if (bonus1 == 0 && bonus2 == 0 && bonus3 != 0) {
            "$bonus3"
        } else if (bonus1 != 0 && bonus2 == 0 && bonus3 != 0) {
            "$bonus1 + $bonus3"
        } else if (bonus1 == 0 && bonus2 != 0 && bonus3 != 0) {
            "$bonus2 + $bonus3"
        } else if (bonus1 != 0 && bonus2 != 0 && bonus3 != 0)
        {
            "$bonus1 + $bonus2 + $bonus3"
        }
        else {
            ""
        }
        diceCalculation += bonus1 + bonus2 + bonus3
        rollString += " = $diceCalculation"

        //Following code adapted from last week's assignment
        //adds the string of dice rolled and their values to the myRolls ArrayList
        myRolls?.add(rollString)

        //Build the adapter and point to the ArrayList previously created
        var arrayAdapter =
            myRolls?.let { ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, it) };

        //Connect the ListView to the ArrayAdapter
        rollsListView.adapter = arrayAdapter;

        rollTextView.gravity = Gravity.CENTER_VERTICAL
        rollTextView.text = rollString
        //Plays sound of dice rolling each click
        //val mediaPlayer: MediaPlayer = MediaPlayer.create(this, R.raw.diceroll)
        //mediaPlayer.start()
    }

    private fun countDice()
    {
        var d4Entered = findViewById<EditText>(R.id.textNumberD4)
        var d6Entered = findViewById<EditText>(R.id.textNumberD6)
        var d8Entered = findViewById<EditText>(R.id.textNumberD8)
        var d10Entered = findViewById<EditText>(R.id.textNumberD10)
        var d12Entered = findViewById<EditText>(R.id.textNumberD12)
        var d20Entered = findViewById<EditText>(R.id.textNumberD20)
        var d100Entered = findViewById<EditText>(R.id.textNumberD100)
        var b1Entered = findViewById<EditText>(R.id.textNumberBonus1)
        var b2Entered = findViewById<EditText>(R.id.textNumberBonus2)
        var b3Entered = findViewById<EditText>(R.id.textNumberBonus3)


        //Determines how many of each dice type are being used
        if (d4Entered.text.toString() != "")
        {
            d4Dice = Integer.parseInt(d4Entered.text.toString())
        }
        if (d6Entered.text.toString() != "")
        {
           d6Dice = Integer.parseInt(d6Entered.text.toString())
        }
        if (d8Entered.text.toString() != "")
        {
            d8Dice = Integer.parseInt(d8Entered.text.toString())
        }
        if (d10Entered.text.toString() != "")
        {
            d10Dice = Integer.parseInt(d10Entered.text.toString())
        }
        if (d12Entered.text.toString() != "")
        {
            d12Dice = Integer.parseInt(d12Entered.text.toString())
        }
        if (d20Entered.text.toString() != "")
        {
            d20Dice = Integer.parseInt(d20Entered.text.toString())
        }
        if (d100Entered.text.toString() != "")
        {
            d100Dice = Integer.parseInt(d100Entered.text.toString())
        }
        if (b1Entered.text.toString() != "")
        {
            bonus1 = Integer.parseInt(b1Entered.text.toString())
        }
        if (b2Entered.text.toString() != "")
        {
            bonus2 = Integer.parseInt(b2Entered.text.toString())
        }
        if (b3Entered.text.toString() != "")
        {
            bonus3 = Integer.parseInt(b3Entered.text.toString())
        }
    }
}